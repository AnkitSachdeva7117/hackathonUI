<template>
  <q-page>
    <div class="col">
      <div class="col">
        <img
          alt="Lines Info"
          src="~assets/applyLines.png"
          style="width: 100%"
        />
      </div>
      <div class="col">
        <router-link to="apply">
          <q-btn color="white" text-color="black" label="Apply" />
        </router-link>
      </div>
    </div>
  </q-page>
</template>

<script>
import { defineComponent } from "vue";

export default defineComponent({
  name: "IndexPage",
});
</script>
