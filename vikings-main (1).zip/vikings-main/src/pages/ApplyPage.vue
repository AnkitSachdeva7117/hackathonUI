<template>
  <div class="q-pa-md">
    <q-stepper v-model="step" ref="stepper" color="primary" contracted animated>
      <q-step
        :name="1"
        title="Autofill"
        icon="settings"
        :done="step > 1"
        style="min-height: 200px"
      >
        <div class="row items-end q-gutter-sm">
          <div class="row">
            <div class="">
              <q-btn
                flat
                style="color: #ff0080"
                label="Existing Customer"
                color="primary"
                @click="existingCustomer = !existingCustomer"
              />
            </div>
            <div class="">
              <q-btn
                flat
                style="color: #ff0080"
                label="New Customer"
                color="primary"
                @click="$refs.stepper.next()"
              />
            </div>
          </div>
        </div>
        <div class="row items-end q-gutter-sm">
          <div class="col-12" v-if="existingCustomer">
            <div class="col-12">
              <div class="row">
                <q-input
                  v-model="username"
                  label="Username"
                  stack-label
                  class="col-12"
                />
              </div>

              <div class="row">
                <q-input
                  v-model="password"
                  label="Password"
                  stack-label
                  class="col-12"
                />
                <div class="row">
                  <q-btn
                    flat
                    style="color: #ff0080"
                    label="Login and Prefill"
                    color="accent"
                    @click="$refs.stepper.next()"
                  />
                </div>
              </div>
            </div>
          </div>
          <div class="col-3"></div>
        </div>
        <q-space />
      </q-step>

      <q-step
        :name="2"
        title="Business Information"
        icon="create_new_folder"
        :done="step > 2"
        style="min-height: 200px"
      >
        <div class="row items-end q-gutter-md q-ma-xs">
          <q-input
            filled
            v-model="legalBusinessName"
            disable
            label="Legal Business Name"
          />
        </div>

        <div class="row items-end q-gutter-md q-ma-xs">
          <q-input filled v-model="entityType" label="Entity Type" disable />
          <q-input filled v-model="taxId" label="EIN" disable />
        </div>

        <div class="row items-end q-gutter-md q-ma-xs">
          <q-input
            filled
            v-model="busAaddressLine1"
            label=" Street Address"
            disable
          />
          <q-input
            filled
            v-model="busAddressLine2"
            label="Street Address Line 2"
            disable
          />
          <q-input filled v-model="busCity" label="City" disable />
          <q-input filled v-model="busState" label="State" disable />
          <q-input filled v-model="busZip" label="Zip" disable />
        </div>
        <q-separator />
        <div class="row items-end q-gutter-md q-ma-xs">
          <q-input filled v-model="o1name" label="First Owner" disable />
          <q-input
            filled
            v-model="o1percent"
            label="Ownership Percentage"
            disable
          />
          <q-separator vertical />
          <div class="row items-end q-gutter-md q-ma-xs">
            <q-input
              filled
              v-model="o1AaddressLine1"
              label=" Street Address"
              disable
            />
            <q-input
              filled
              v-model="o1AddressLine2"
              label="Street Address Line 2"
              disable
            />
            <q-input filled v-model="o1City" label="City" disable />
            <q-input filled v-model="o1State" label="State" disable />
            <q-input filled v-model="o1Zip" label="Zip" disable />
          </div>
        </div>

        <q-separator />
        <div class="row items-end q-gutter-md q-ma-xs">
          <q-input filled v-model="o2name" label="Second Owner" disable />
          <q-input
            filled
            v-model="o2percent"
            label="Ownership Percentage"
            disable
          />
          <q-separator vertical />
          <div class="row items-end q-gutter-md q-ma-xs">
            <q-input
              filled
              v-model="o2AaddressLine1"
              label=" Street Address"
              disable
            />
            <q-input
              filled
              v-model="o2AddressLine2"
              label="Street Address Line 2"
              disable
            />
            <q-input filled v-model="o2City" label="City" disable />
            <q-input filled v-model="o2State" label="State" disable />
            <q-input filled v-model="o2Zip" label="Zip" disable />
          </div>
        </div>
      </q-step>

      <q-step
        :name="3"
        title="Ownership"
        icon="create_new_folder"
        :done="step > 3"
        style="min-height: 200px"
      >
        <div
          class="row justify-center q-gutter-md q-ma-xs"
          v-if="hideProgressBar"
        >
          <q-linear-progress
            stripe
            size="10px"
            :value="progress1"
            :buffer="buffer1"
          />
        </div>
        <div
          class="row justify-center q-gutter-md q-ma-xs"
          v-if="hideProgressBar"
        >
          {{ loadingmessage }}
        </div>

        <div class="row q-gutter-md q-ma-xs" v-if="!hideProgressBar">
          <div>
            Basis your information, we request you to upload the below documents
          </div>
          <ul>
            <li>Driving License</li>
            <li>Business Registration</li>
          </ul>
        </div>

        <div class="row q-gutter-md q-ma-xs" v-if="!hideProgressBar">
          <div col-6>
            <q-uploader
              label="Upload your Driving license and Business Registration"
              max-file-size="10048"
              @rejected="onRejected"
              auto-upload
              multiple
              flat
            />
          </div>
        </div>
      </q-step>

      <q-step
        :name="4"
        title="Customize Account"
        icon="create_new_folder"
        :done="step > 4"
        style="min-height: 200px"
      >
        <div class="row justify-center q-gutter-md q-ma-xs">
          <q-linear-progress
            stripe
            size="10px"
            :value="progress2"
            :buffer="buffer2"
          />
        </div>
        <div class="row justify-center q-gutter-md q-ma-xs">
          {{ submitmessage }}
        </div>
      </q-step>

      <template v-slot:navigation>
        <q-stepper-navigation>
          <q-btn
            v-if="step == 2"
            @click="$refs.stepper.next()"
            color="accent"
            :label="'Next'"
          />

          <q-btn
            v-if="step == 3 && !loading"
            @click="$refs.stepper.next()"
            color="accent"
            :label="'Submit Application'"
          />
          <q-btn
            v-if="step == 2"
            flat
            color="accent"
            @click="$refs.stepper.previous()"
            label="Back"
            class="q-ml-sm"
          />
          <router-link to="status"
            ><q-btn
              v-if="step === 4 && !loading"
              @click="$refs.stepper.next()"
              color="accent"
              label="Check Status"
          /></router-link>
        </q-stepper-navigation>
      </template>

      <template v-slot:message>
        <q-banner v-if="step === 1" class="bg-grey-2 text-black q-px-lg">
          If you're an existing customer, login below to prefill your
          application.
        </q-banner>
        <q-banner
          v-else-if="step === 2"
          class="bg-light-green-1 text-black q-px-lg"
        >
          We've prefilled your application. Incase of discrepancy, please reach
          out to support.
        </q-banner>
        <q-banner v-else-if="step === 3" class="bg-grey-2 text-black q-px-lg">
          Please upload the below documents for a quick decisioning
        </q-banner>
        <q-banner v-else class="bg-grey-2 text-black q-px-lg">
          The final step...
        </q-banner>
      </template>
    </q-stepper>
  </div>
</template>

<script>
import { defineComponent } from "vue";
import { ref, watch } from "vue";
import { useQuasar } from "quasar";

export default defineComponent({
  name: "ApplyPage",

  setup() {
    const $q = useQuasar();
    const name = ref(null);
    const age = ref(null);
    const accept = ref(false);
    const businessName = ref(null);
    const onGoogle = ref(false);
    const businessSearch = ref("");
    const dba = ref("false");
    const dense = ref(true);
    const dbaName = ref("");
    const step = ref(1);
    const existingCustomer = ref(false);
    const username = ref("callie");
    const password = ref("********");
    const legalBusinessName = ref("SB Enterprise LLC");
    const taxId = ref("****-****-****-1829");
    const entityType = ref("LLC");

    const busAddressLine2 = ref(" ");
    const busAaddressLine1 = ref("123 Park Street");
    const busCity = ref("Cupertino");
    const busState = ref("California");
    const busZip = ref("80130");

    const o1name = ref("James Dean");
    const o1percent = ref("60%");
    const o1AddressLine2 = ref(" ");
    const o1AaddressLine1 = ref("ABC Park Street");
    const o1City = ref("Cupertino");
    const o1State = ref("California");
    const o1Zip = ref("80135");

    const o2name = ref("Jackie Chan");
    const o2percent = ref("40%");
    const o2AddressLine2 = ref(" ");
    const o2AaddressLine1 = ref("123 None Street");
    const o2City = ref("Cupertino");
    const o2State = ref("California");
    const o2Zip = ref("80137");

    const busSector = ref("Miscellaneous crop farming");

    const progress1 = ref("0");
    const buffer1 = ref("0");
    const loadingmessage = ref("Validating Information");

    const hideProgressBar = ref("false");

    const progress2 = ref("0");
    const buffer2 = ref("0");
    const submitmessage = ref("Validating Information");

    const loading = ref("false");

    watch(step, (newValue, oldValue) => {
      if (newValue == 3) {
        setInterval(() => {
          // if (progress1.value >= 1) {
          //   progress1.value = 0.01;
          //   buffer1.value = 0.01;
          //   return;
          // }
          progress1.value = Math.min(1, buffer1.value, progress1.value + 0.25);
        }, 700 + Math.random() * 1000);

        setInterval(() => {
          if (buffer1.value < 1) {
            buffer1.value = Math.min(1, buffer1.value + Math.random() * 0.5);
          }
        }, 700);
      }

      if (newValue == 4) {
        setInterval(() => {
          progress2.value = Math.min(1, buffer2.value, progress2.value + 0.25);
        }, 700 + Math.random() * 1000);

        setInterval(() => {
          if (buffer2.value < 1) {
            buffer2.value = Math.min(1, buffer2.value + Math.random() * 0.5);
          }
        }, 700);
      }
    });

    watch(progress1, (newValue, oldValue) => {
      if (newValue < 0.4) {
        loading.value = true;
        loadingmessage.value = "Validating information";

        hideProgressBar.value = true;
      } else if (newValue < 0.8) {
        loading.value = true;
        loadingmessage.value = "Validating profile";
        hideProgressBar.value = true;
      } else {
        loadingmessage.value = "Determining need for additional documents";

        setInterval(() => {
          hideProgressBar.value = false;
          loading.value = false;
        }, 2000);
      }
    });

    watch(progress2, (newValue, oldValue) => {
      if (newValue < 0.4) {
        loading.value = true;
        submitmessage.value = "Validating information";

        hideProgressBar.value = true;
        console.log(hideProgressBar.value);
      } else if (newValue < 0.95) {
        loading.value = true;
        submitmessage.value = "Verifying Documents";
        // console.log(hideProgressBar.value);
      } else {
        submitmessage.value = "Submission Successful";
        loading.value = false;
      }
    });

    return {
      step,
      name,
      age,
      accept,
      businessName,
      onGoogle,
      businessSearch,
      dense,
      dba,
      dbaName,
      existingCustomer,
      username,
      password,
      legalBusinessName,
      taxId,
      entityType,
      busAaddressLine1,
      busAddressLine2,
      busCity,
      busZip,
      busState,
      o1name,
      o1percent,
      o1AaddressLine1,
      o1AddressLine2,
      o1City,
      o1State,
      o1Zip,
      o2name,
      o2percent,
      o2AaddressLine1,
      o2AddressLine2,
      o2City,
      o2State,
      o2Zip,
      progress1,
      buffer1,
      loadingmessage,
      hideProgressBar,
      progress2,
      buffer2,
      submitmessage,
      loading,

      setPlace() {
        console.log("setplace");
      },
      onRejected(rejectedEntries) {
        // Notify plugin needs to be installed
        // https://quasar.dev/quasar-plugins/notify#Installation
        $q.notify({
          type: "negative",
          message: `${rejectedEntries.length} file(s) did not pass validation constraints`,
        });
      },
      toggleLeftDrawer() {
        leftDrawerOpen.value = !leftDrawerOpen.value;
        console.log(`value of left drawer ${leftDrawerOpen.value}`);
      },
    };
  },
});
</script>
