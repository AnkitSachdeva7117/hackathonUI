<template>
  <div class="q-pa-md">
    <q-timeline color="secondary">
      <q-timeline-entry heading> Application #124123 </q-timeline-entry>

      <q-timeline-entry
        title="Funds disbursed"
        subtitle="Estimated by October 20, 2022 11:00 PT"
        style="color: gray"
      >
        <div>Your funds will disbursed to your account and ready for use</div>
      </q-timeline-entry>

      <q-timeline-entry
        title="Under Review"
        subtitle="Estimated Update In 5 hours"
        style="color: gray"
      >
        <div>Application is being reviewed by our team</div>
      </q-timeline-entry>
      <q-timeline-entry
        title="Submitted for processing"
        subtitle="October 19, 2022 19:30 PT"
        icon="done"
      >
        <div>We've got your application</div>
      </q-timeline-entry>
      <q-timeline-entry
        title="Documents Verified"
        subtitle="October 19, 2022 19:10 PT"
        icon="done"
      >
        <div>The required documents are verified</div>
      </q-timeline-entry>

      <q-timeline-entry
        title="Documents Uploaded"
        subtitle="October 19, 2022 19:09 PT"
        icon="done"
      >
        <div>The required documents are uploaded</div>
      </q-timeline-entry>
    </q-timeline>
  </div>
</template>

<script>
import { defineComponent } from "vue";
import { ref } from "vue";

export default defineComponent({
  name: "StatusPage",

  setup() {
    const name = ref(null);
    const age = ref(null);
    const accept = ref(false);
    const businessName = ref(null);
    const onGoogle = ref(false);
    const businessSearch = ref("");
    const dba = ref("false");
    const entityType = ref([]);
    const dense = ref(true);
    const dbaName = ref("");

    return {
      step: ref(1),
      name,
      age,
      accept,
      businessName,
      onGoogle,
      businessSearch,
      dense,
      dba,
      entityType,
      dbaName,

      toggleLeftDrawer() {
        leftDrawerOpen.value = !leftDrawerOpen.value;
        console.log(`value of left drawer ${leftDrawerOpen.value}`);
      },
    };
  },
});
</script>
