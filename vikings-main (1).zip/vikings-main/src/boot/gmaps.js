import { boot } from "quasar/wrappers";
import VueGoogleMaps from "@fawmi/vue-google-maps";

// export default async ({ app, router, store }) => {
//   app
//     .use(VueGoogleMaps, {
//       load: {
//         key: "AIzaSyCpbfF_QxXomgkXNh9CbQsZSL7C6UW0vaw",
//         libraries: "places",
//         // language: 'de',
//       },
//     })
//     .mount("#app");
// };

export default (app, router, store) => {
  app.use(VueGoogleMaps, {
    load: {
      key: "AIzaSyCpbfF_QxXomgkXNh9CbQsZSL7C6UW0vaw",
      libraries: "places",
      // language: 'de',
    },
  });
};

export { VueGoogleMaps };
