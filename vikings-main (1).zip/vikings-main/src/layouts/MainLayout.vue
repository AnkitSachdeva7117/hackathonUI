<template>
  <q-layout view="lHh Lpr lFf">
    <q-header elevated>
      <q-toolbar>
        <q-toolbar-title>
          <img
            src="https://www17.wellsfargomedia.com/assets/images/rwd/wf_logo_220x23.png"
            class="logo"
            alt="Wells Fargo Home Page"
          />
        </q-toolbar-title>

        <div>
          <q-btn
            flat
            dense
            round
            icon="menu"
            aria-label="Menu"
            @click="toggleLeftDrawer"
          />
        </div>
      </q-toolbar>
    </q-header>

    <q-drawer v-model="leftDrawerOpen" show-if-above bordered side="right">
      <q-list>
        <q-item-label header> Essential Links </q-item-label>

        <EssentialLink
          v-for="link in essentialLinks"
          :key="link.title"
          v-bind="link"
        />
      </q-list>
    </q-drawer>

    <q-page-container>
      <router-view />
    </q-page-container>
  </q-layout>
</template>

<script>
import { defineComponent, ref } from "vue";
import EssentialLink from "components/EssentialLink.vue";

const linksList = [
  {
    title: "Home",
    caption: "Line of Credit",
    icon: "school",
    link: "#/",
  },
  {
    title: "Apply",
    caption: "Rates and Terms",
    icon: "school",
    link: "#/apply",
  },
  {
    title: "Status",
    caption: "Check Status",
    icon: "code",
    link: "#/status",
  },
];

export default defineComponent({
  name: "MainLayout",

  components: {
    EssentialLink,
  },

  setup() {
    const leftDrawerOpen = ref(false);

    console.log(`value of left drawer ${leftDrawerOpen.value}`);

    return {
      essentialLinks: linksList,
      leftDrawerOpen,
      toggleLeftDrawer() {
        leftDrawerOpen.value = !leftDrawerOpen.value;
        console.log(`value of left drawer ${leftDrawerOpen.value}`);
      },
    };
  },
});
</script>

<style>
.logo {
  width: 159px;
}
</style>
